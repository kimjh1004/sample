package com.mudchobo.examples.multipledatabase;

import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.annotation.Bean;
import org.springframework.transaction.annotation.EnableTransactionManagement;

import com.mudchobo.examples.multipledatabase.domain.Hello;
import com.mudchobo.examples.multipledatabase.masterrepository.HelloRepository;
import com.mudchobo.examples.multipledatabase.slaverepository.HelloSlaveRepository;

@Slf4j
@EnableTransactionManagement
@SpringBootApplication
public class SpringBlogApplication {

	public static void main(String[] args) {
		SpringApplication.run(SpringBlogApplication.class, args);
	}
	
	@Bean
    public CommandLineRunner demo(HelloRepository helloRepository, HelloSlaveRepository helloSlaveRepository) {
        return args -> {
            var savedHello = helloRepository.save(Hello.builder().coment("hp7 코멘트").world("hp7입니다!!").build());
            log.info("savedHello = {}", savedHello);

            var slaveSavedHello = helloSlaveRepository.save(Hello.builder().coment("hp99 코멘트").world("hp99입니다!!").build());
            log.info("slaveSavedHello = {}", slaveSavedHello);
            
            var masterHello = helloRepository.findById(1L);
            log.info("masterHello = {}", masterHello);

            var slaveHello = helloSlaveRepository.findById(1L);
            log.info("slaveHello = {}", slaveHello);
        };
    }

}
