package com.mudchobo.examples.multipledatabase.domain;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;

@Entity
@Data
@Builder
@AllArgsConstructor
@NoArgsConstructor
@Table(name = "SAMPLE")  
/*
 * @SequenceGenerator( name = "TEST", sequenceName = "TEST_SEQ", // 매핑할 데이터베이스
 * 시퀀스 이름 initialValue = 1, allocationSize = 1)
 */
public class Hello {
    
	//@GeneratedValue(strategy = GenerationType.SEQUENCE, generator = "TEST")
	
	@Id
    long id;

    @Column
    String world;
    
    @Column
    String coment;
}