package com.first.blog;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBlogApplicationTests {

	@Test
	void contextLoads() {
	}

}
